<?php
if(isset($_POST['submit'])){
    try{
        include 'include/DatabaseConnection.php';
        include 'include/DatabaseFunctions.php';

        // Handle file upload
        $uploadFile = '';
        if (isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['name'] !== '') {
            // Check for upload errors
            if ($_FILES['fileToUpload']['error'] !== UPLOAD_ERR_OK) {
                switch ($_FILES['fileToUpload']['error']) {
                    case UPLOAD_ERR_INI_SIZE:
                        throw new Exception('The uploaded file exceeds the upload_max_filesize directive in php.ini');
                    case UPLOAD_ERR_FORM_SIZE:
                        throw new Exception('The uploaded file exceeds the MAX_FILE_SIZE directive in the HTML form');
                    case UPLOAD_ERR_PARTIAL:
                        throw new Exception('The uploaded file was only partially uploaded');
                    case UPLOAD_ERR_NO_FILE:
                        throw new Exception('No file was uploaded');
                    default:
                        throw new Exception('Unknown upload error');
                }
            }

            // Create uploads directory if it doesn't exist
            $uploadDir = __DIR__ . '/uploads/';
            if (!file_exists($uploadDir)) {
                if (!mkdir($uploadDir, 0777, true)) {
                    throw new Exception('Failed to create upload directory');
                }
                chmod($uploadDir, 0777);
            }

            // Generate unique filename
            $fileInfo = pathinfo($_FILES['fileToUpload']['name']);
            $extension = isset($fileInfo['extension']) ? '.' . $fileInfo['extension'] : '';
            $uploadFile = uniqid() . $extension;
            $targetPath = $uploadDir . $uploadFile;
            
            // Check if file is an actual image
            $check = getimagesize($_FILES['fileToUpload']['tmp_name']);
            if ($check === false) {
                throw new Exception('File is not an image');
            }

            // Try to move the uploaded file
            if (!move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetPath)) {
                $error = error_get_last();
                throw new Exception('Failed to move uploaded file. Error: ' . ($error['message'] ?? 'Unknown error'));
            }
        }

        // Insert post into database
        insertPost($pdo, $_POST['postQuestion'], $uploadFile, $_POST['users'], $_POST['module']);
        header('location: posts.php');
        exit();
    } catch (PDOException $e) {
        $title = 'An error has occurred';
        $output = 'Database error: ' . $e->getMessage();
    } catch (Exception $e) {
        $title = 'An error has occurred';
        $output = 'Upload error: ' . $e->getMessage();
    }
} else {
    include 'include/DatabaseConnection.php';
    include 'include/DatabaseFunctions.php';
    $title = "Add a new post";
    $users = allUsers($pdo);
    $modules = allModule($pdo);
    ob_start();
    include 'templates/addposts.html.php';
    $output = ob_get_clean();
}
include 'templates/layout.html.php';