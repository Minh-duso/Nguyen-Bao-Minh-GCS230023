<?php
require 'include/DatabaseConnection.php';
require 'include/DatabaseFunctions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize inputs
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $comment = trim($_POST['comment'] ?? '');

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die('Invalid email format');
    }

    // Validate comment
    if (empty($comment)) {
        die('Comment cannot be empty');
    }

    try {
        // Insert the feedback
        $query = 'INSERT INTO user_message (feedback_message, email, time, user_id) 
                 VALUES (:comment, :email, NOW(), :user_id)';
        
        $parameters = [
            ':comment' => $comment,
            ':email' => $email,
            ':user_id' => 1 // Default user ID for feedback
        ];

        query($pdo, $query, $parameters);
        
        // Redirect to thank you page
        header('Location: thank_you.php');
        exit();
    } catch (PDOException $e) {
        // Log error (in a production environment)
        error_log('Feedback submission error: ' . $e->getMessage());
        
        // Show user-friendly error
        die('Sorry, there was an error submitting your feedback. Please try again later.');
    }
} else {
    // If not POST request, redirect to feedback form
    header('Location: feedback.php');
    exit();
}
?>
