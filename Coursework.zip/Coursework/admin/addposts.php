<?php
require "login/Check.php";
if(isset($_POST['postQuestion'])){
    try{
        
        include '../include/DatabaseConnection.php';
        include '../include/DatabaseFunctions.php';
        insertPost($pdo, $_POST['postQuestion'],$_FILES['fileToUpload']['nameStudent'] ,$_POST['users'], $_POST['module']);
        
        include '../include/uploadFile.php';
        
        header('location: posts.php');
    }catch (PDOException $e){
        $title = 'An error has occured';
        $output = 'Database error: ' . $e->getMessage();
    }
}else{
    include '../include/DatabaseConnection.php';
    include '../include/DatabaseFunctions.php';
    $title = "Add a new post";
    $users = allUsers($pdo);
    $modules = allModule($pdo);
    ob_start();
    include '../templates/addposts.html.php';
    $output= ob_get_clean();
}
include '../templates/admin_layout.html.php'; 