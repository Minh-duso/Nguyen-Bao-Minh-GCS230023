<?php
include '../include/DatabaseConnection.php';
include '../include/DatabaseFunctions.php';

try {
    if (isset($_POST['postQuestion'])) {
        // Only update the question content
        $sql = 'UPDATE posts SET postQuestion = :postQuestion WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'postQuestion' => $_POST['postQuestion'],
            'id' => $_POST['postid']
        ]);
        
        header('location: posts.php');
        exit();
    } else {
        // Get post with module and student name
        $sql = 'SELECT p.*, m.nameModule, u.nameStudent 
                FROM posts p 
                JOIN modules m ON p.moduleid = m.id
                JOIN users u ON p.userid = u.id 
                WHERE p.id = :id';
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id' => $_GET['id']]);
        $post = $stmt->fetch();

        $title = 'Edit Question';
        ob_start();
        include '../templates/editposts.html.php';
        $output = ob_get_clean();
    }
} catch (PDOException $e) {
    $title = 'An error has occurred';
    $output = 'Error editing question: ' . $e->getMessage();
}

include '../templates/admin_layout.html.php';