<?php
try{
    include '../include/DatabaseConnection.php';
    include '../include/DatabaseFunctions.php';
    $row = getPost($pdo,$_POST['id']);
    unlink('..uploads/'.$row['image']);
    deletePost($pdo, $_POST['id']);
    header('location: posts.php');
}catch(PDOException $e){
    $title = 'An error has occured';
    $output = 'Unable to connect to delete post:' .$e->getMessage();
}
include '../templates/admin_layout.html.php';
