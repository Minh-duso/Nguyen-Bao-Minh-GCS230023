<?php
session_start();

include 'include/DatabaseConnection.php';
include 'include/DatabaseFunctions.php';

try {
    // Check if we have a post ID
    if (!isset($_GET['id']) && !isset($_POST['postid'])) {
        header('location: posts.php');
        exit();
    }

    $postId = $_GET['id'] ?? $_POST['postid'];

    if (isset($_POST['submit'])) {
        // Validate input
        if (empty($_POST['postQuestion'])) {
            throw new Exception('Question cannot be empty');
        }

        // Update post
        updatePost($pdo, $_POST['postid'], $_POST['postQuestion']);
        updateUserAndModule($pdo, $_POST['postid'], $_POST['users'], $_POST['module']);
        
        header('location: posts.php?success=Post updated successfully');
        exit();
    }

    // Get post data for editing
    $post = getPost($pdo, $postId);
    if (!$post) {
        header('location: posts.php?error=Post not found');
        exit();
    }

    $users = allUsers($pdo);
    $modules = allModule($pdo);
    $title = 'Edit Question';

    ob_start();
    include 'templates/editposts.html.php';
    $output = ob_get_clean();

} catch (PDOException $e) {
    $title = 'Error has occurred';
    $output = 'Database error: ' . $e->getMessage();
} catch (Exception $e) {
    $title = 'Error has occurred';
    $output = $e->getMessage();
}

include 'templates/layout.html.php';
