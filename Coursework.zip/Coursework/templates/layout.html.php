<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <link rel="stylesheet" href="posts.css">
    <title>Student Web</title>
</head>
<body>
    <header><h1>Student Forum</h1></header>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="posts.php">Question List </a></li>
            <li><a href="addpost.php">Add a new question</a></li> 
            <li><a href="admin/login/admin_login.html">Admin Login Only</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="add_edit_deleteuser.php">Add a new user</a></li>
            <li><a href="add_edit_deletemodule.php">Add a new module</a></li>
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    
</body>
</html>