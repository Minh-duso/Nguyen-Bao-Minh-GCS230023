<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
     <link rel="stylesheet" href="../posts.css">
    <title>Welcome to Question Web</title>
</head>
<body>
    <header id="admin">
        <h1>Admin Dashboard<br />
        Manage Questions, Modules and Students </h1></header>
    <nav>
        <ul>
            <li><a href="../admin/message.php">Message from user</a></li>
            <li><a href="posts.php">Question List to Delete</a></li>
            <li><a href="login/Logout.php">Public facing web site/Logout</a></li> 
        </ul>
    </nav>
    <main>
        <?=$output?>
    </main>
    <footer>&copy; Admin 2024</footer>
</body>
</html>