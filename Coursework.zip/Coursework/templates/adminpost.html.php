<div class="questions-list">
    <h2>Questions List</h2>
    <p class="total-posts"><?=$totalposts?> Questions have been posted</p>

    <?php foreach($posts as $post): ?>
        <div class="question-card">
            <div class="question-content">
                <div class="question-header">
                    <div class="question-meta">
                        <span class="date"><?=date("D d M Y", strtotime($post['date']))?></span>
                        <span class="module">Module: <?=htmlspecialchars($post['nameModule'], ENT_QUOTES, 'UTF-8')?></span>
                        <span class="student">Posted by: 
                            <a href="mailto:<?=htmlspecialchars($post['nameStudent'], ENT_QUOTES, "UTF-8" );?>">
                                <?=htmlspecialchars($post['nameStudent'], ENT_QUOTES, 'UTF-8'); ?>
                            </a>
                        </span>
                    </div>
                </div>

                <div class="question-body">
                    <p class="question-text"><?=htmlspecialchars($post['postQuestion'], ENT_QUOTES,'UTF-8')?></p>
                    
                    <?php if (!empty($post['uploads'])): ?>
                        <div class="question-image">
                            <img src="../uploads/<?=htmlspecialchars($post['uploads'], ENT_QUOTES, 'UTF-8'); ?>" 
                                 alt="Question attachment">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="question-actions">
                    <form action="deleteposts.php" method="post" class="delete-form" onsubmit="return confirm('Are you sure you want to delete this question?');">
                        <input type="hidden" name="id" value="<?=$post['id']?>">
                        <button type="submit" class="delete-btn">Delete Question</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<style>
/* Admin post list styles */
.questions-list {
    padding: 20px;
}

.question-card {
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
    padding: 20px;
}

.question-header {
    margin-bottom: 15px;
}

.question-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    color: #666;
    font-size: 0.9em;
}

.question-meta span {
    display: inline-flex;
    align-items: center;
}

.question-meta a {
    color: #007bff;
    text-decoration: none;
}

.question-meta a:hover {
    text-decoration: underline;
}

.question-body {
    margin: 15px 0;
}

.question-text {
    font-size: 1.1em;
    line-height: 1.5;
    color: #333;
    margin-bottom: 15px;
}

.question-image img {
    max-width: 100%;
    max-height: 300px;
    border-radius: 4px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.question-actions {
    margin-top: 15px;
    border-top: 1px solid #eee;
    padding-top: 15px;
}

.delete-form {
    display: inline-block;
}

.delete-btn {
    background-color: #dc3545;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: 500;
    transition: background-color 0.2s;
}

.delete-btn:hover {
    background-color: #c82333;
}

.total-posts {
    color: #666;
    margin-bottom: 20px;
    font-size: 1.1em;
}
</style>