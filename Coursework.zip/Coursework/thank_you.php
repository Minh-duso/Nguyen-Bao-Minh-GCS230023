<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta nameStudent="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: url('thankyou.png');
            background-size: cover;
            color: #fff;
            text-align: center;
        }

        .container {
            background: rgba(0, 0, 0, 0.6); /* Adds a transparent overlay */
            padding: 30px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2em;
            margin-bottom: 20px;
        }

        a {
            font-size: 1em;
            color: #ffd700;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank you for your feedback!</h1>
        <p>Your comment has been submitted successfully. Our team will review it shortly.</p>
        <a href="index.php">Go back to homepage</a>
    </div>
</body>
</html>
