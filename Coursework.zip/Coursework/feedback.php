<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
</head>
<style>
/* Body styling */
body {
    background: url('feedbacki.jpg');
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Feedback container */
.feedback-container {
    background: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
}

.feedback-container h1 {
    color: #333;
    margin-bottom: 25px;
    text-align: center;
    font-size: 24px;
}

/* Form elements */
.feedback-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.feedback-form .form-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.feedback-form label {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

.feedback-form input,
.feedback-form textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    transition: all 0.3s ease;
}

.feedback-form input:focus,
.feedback-form textarea:focus {
    border-color: #007BFF;
    box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.1);
    outline: none;
}

.feedback-form textarea {
    resize: vertical;
    min-height: 120px;
}

/* Submit button */
.submit-btn {
    background-color: #007BFF;
    color: #fff;
    border: none;
    padding: 12px;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-top: 10px;
}

.submit-btn:hover {
    background-color: #0056b3;
    transform: translateY(-1px);
}

.submit-btn:active {
    transform: translateY(0);
}

/* Error messages */
.error {
    color: #dc3545;
    font-size: 14px;
    margin-top: 4px;
}
</style>
<body>
    <div class="feedback-container">
        <h1>Submit Your Feedback</h1>
        <form action="feedback_process.php" method="post" class="feedback-form">
            <div class="form-group">
                <label for="email">Your Email:</label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       placeholder="Enter your email" 
                       required>
            </div>

            <div class="form-group">
                <label for="comment">Your Comment:</label>
                <textarea id="comment" 
                          name="comment" 
                          rows="5" 
                          placeholder="Write your comment here..." 
                          required></textarea>
            </div>

            <button type="submit" class="submit-btn">Submit Feedback</button>
        </form>
    </div>
</body>
</html>
